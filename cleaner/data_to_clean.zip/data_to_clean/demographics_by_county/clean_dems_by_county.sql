PRAGMA foreign_keys = ON;
.headers on
.mode csv
.import demographics_by_county.csv og_data
.mode column

/* Remove any age group that can't vote */
DELETE FROM og_data
WHERE AGEGRP < 5;

/* Remove any years that aren't the year we're using in dataset (2016) */
DELETE FROM og_data
WHERE year != 9;

/*
	Take only the FIPS, state, county, male, female,
	white male/female, black male/female, hispanic male/female,
	and asian male/female

	Add up the total of the population that is of the age to vote 
	Utilizing a group by county and summation of population by demographic
/*

/* CREATE THE CSV FILE OF CLEAN DATA */
 
.mode csv
.output clean_dems_by_county.csv

SELECT
	STATE * 1000 + COUNTY as fips,
	STNAME as state,
	CTYNAME as county,
	SUM(TOT_MALE) as male,
	SUM(TOT_FEMALE) as female,
	SUM(WA_MALE) as white_male,
	SUM(WA_FEMALE) as white_female,
	SUM(BA_MALE) as black_male,
	SUM(BA_FEMALE) as black_female,
	SUM(H_MALE) as hispanic_male,
	SUM(H_FEMALE) as hispanic_female,
	SUM(AA_MALE) as asian_male,
	SUM(AA_FEMALE) as asian_female
	
	
FROM
	og_data
GROUP BY
	fips
ORDER BY
	fips asc;
