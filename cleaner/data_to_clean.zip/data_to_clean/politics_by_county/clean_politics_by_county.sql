PRAGMA foreign_keys = ON;
DROP TABLE IF EXISTS cases_by_county;
DROP TABLE IF EXISTS old_politics_by_county;
DROP TABLE IF EXISTS politics_by_county;

.headers on
.mode csv

.import cases_by_county.csv cases_by_county
.schema cases_by_county

.import political_party_affiliation_by_county.csv old_politics_by_county
.schema old_politics_by_county

.mode column

/* 
	Create new table that will be the result of a query from
	old_politics_by_county
	where the year is more recent than 2012
	(So 2016 because the most recent year before that is 2012)
	
	Also filters out "NA" in party column

	This is a temporary table until I can do math on the candidatevotes
	and totalvotes tables to create the final column (vote_ratio)
*/

CREATE TABLE politics_by_county(
	fips INTEGER NOT NULL,
	year INTEGER NOT NULL,
	state TEXT NOT NULL,
	county TEXT NOT NULL,
	candidate_party TEXT NOT NULL,
	candidate_votes FLOAT NOT NULL,
	total_votes FLOAT NOT NULL
);

INSERT INTO politics_by_county(
	fips, 
	year, 
	state, 
	county, 
	candidate_party, 
	candidate_votes, 
	total_votes)
SELECT
	fips,
	year,
	state,
	county,
	party,
	candidatevotes,
	totalvotes

FROM
	old_politics_by_county
WHERE
	CAST(year as INTEGER) > 2012
	AND party != 'NA';

/*
	Add vote_ratio into politics_by_county
	set correct values to vote_ratio with UPDATE
*/

ALTER TABLE politics_by_county
	ADD vote_ratio FLOAT;

UPDATE politics_by_county
	SET vote_ratio = round(candidate_votes/total_votes, 2);


/*
	Display the results of the election by dividing the totalvotes by candidatevotes
	and storing it in "vote_ratio"

	use vote_ratio and party to determine the party that won the specific election in that county.
	(If vote_ratio > .5 and party == democrat) Will display which counties voted democratic,
	and the reverse will display which counties voted republican

	--Will DELETE ALL REPUBLICANS--
	Only need ONE parties total votes, because if their threshold is under .5 then the opposite party
	won that county. This AVOIDS duplicates as well, since the party is binary (republican/democrat)

	The amount of times that a state name appears in these tables corresponds to the way they voted.
	If Alabama appears 10x in the Republican table, and 5x in Democratic then Alabama voted republican.
	Since the tables represent the counties in that state, the amount of times that a state appears 
	shows how many counties in that state voted for that party.
*/

DELETE FROM politics_by_county
	WHERE candidate_party LIKE '%republican%';

DELETE FROM politics_by_county
	WHERE fips LIKE '%NA%';

ALTER TABLE politics_by_county
	ADD county_party;

UPDATE politics_by_county
	SET county_party = 
		CASE
		WHEN vote_ratio >.5
			THEN 'democrat' 
			ELSE 'republican'
		END;

/*
	Remove excess data. Year, Candidate_votes, candidate_party, vote_ratio
	They were only needed to get to this point of data consolidation, and
	now we can use it more coherently
	
	To do so I have to create a final table, copy over the data I want, and 
	remove the previous table
*/
CREATE TABLE clean_politics_by_county(
	fips,
	state,
	county,
	political_affiliation	
);

INSERT INTO clean_politics_by_county(
	fips,
	state,
	county,
	political_affiliation
)
SELECT
	fips,
	state,
	county,
	county_party
FROM
	politics_by_county
ORDER BY
	fips ASC;

/* CREATE THE CSV FILE OF CLEAN DATA */
.mode csv
.output 2016_cleaned_politics_by_county.csv
SELECT 
	*
FROM
	clean_politics_by_county;
.quit

/* WOO WE DONE */
