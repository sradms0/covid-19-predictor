PRAGMA foreign_keys = ON;
.headers on
.mode csv
.import 2016_cleaned_politics_by_county.csv politics_by_county
.import clean_dems_by_county.csv dems_by_county
.import cleaned_covid_cases_by_county.csv covid_by_county
.mode column

/* CREATE THE CSV FILE OF CLEAN DATA */
.mode csv
.output clean_data.csv

SELECT
	CAST(dems_by_county.fips as INT) as FIPS,
	dems_by_county.state,
	dems_by_county.county,
	male,
	female,
	white_male,
	white_female,
	black_male,
	black_female,
	hispanic_male,
	hispanic_female,
	asian_male,
	asian_female,
	CAST(cases as INT) as cases,
	political_affiliation
FROM
	dems_by_county
INNER JOIN
	covid_by_county
	ON dems_by_county.fips = covid_by_county.fips
INNER JOIN
	politics_by_county
	ON dems_by_county.fips = politics_by_county.fips
ORDER BY
	FIPS asc;
