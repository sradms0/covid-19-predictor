PRAGMA foreign_keys = ON;
DROP TABLE IF EXISTS cases_by_county;
DROP TABLE IF EXISTS og_data;
.headers on
.mode csv
.import cases_by_county.csv og_data

.mode column

/* Remove Date Column */
/* To do so I have to create a new table that doesn't copy over the column data for date from the previous */

CREATE TABLE cases_by_county(
	fips TEXT NOT NULL,
	state TEXT NOT NULL,
	county TEXT NOT NULL,
	cases INT NOT NULL
);

INSERT INTO cases_by_county(
	fips,
	state,
	county,
	cases
)

SELECT
	CAST(fips as INT),
	state,
	county,
	CAST(cases as INT)
FROM
	og_data
ORDER BY
	fips ASC;
select * from cases_by_county limit 100;

/* Remove FIPS with value < 1 */
DELETE FROM cases_by_county
WHERE
	fips == 0;

/* Consolidate cases data for each county */
/* CREATE THE CSV FILE OF CLEAN DATA */
.mode csv
.output cleaned_covid_cases_by_county.csv
SELECT 
	fips,
	state,
	county,
	sum(cases) as cases
FROM
	cases_by_county
GROUP BY county
ORDER BY state;
.quit

/*Done*/
